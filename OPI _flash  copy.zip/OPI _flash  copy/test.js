// 1.   Top ボタンのclick時imglistのランダム関数始まる 
// 1.5  
// let levels = ["begin","normal","pro"];

// document.getElementById("begin").onclick = function() {
//   document.getElementById("top").style.display = "none";
//   document.getElementById("flash").style.display = "block";
// };
// document.getElementById("normal").onclick = function() {
//   document.getElementById("top").style.display = "none";
//   document.getElementById("flash").style.display = "block";
// };
// document.getElementById("pro").onclick = function() {
//   document.getElementById("top").style.display = "none";
//   document.getElementById("flash").style.display = "block";
// };

// 2.imglist配列の力一つを所得

// 3.所得したimglilst番号を下記のランダム関数に当てはめる。